
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;

public class MyTextEditor extends JFrame {

	// Panel North
	JPanel pnlNorth;
	JLabel lblFont;
	JSpinner spnFontSize;
	JComboBox cmbFont;
	JButton btnFontColor;
	
	//Text Editor
	JScrollPane scpEditor;
	JTextArea txaEditor;

	// Menu Bar
	JMenuBar menuBar;
	JMenu mnuFile;
	JMenuItem mitOpen;
	JMenuItem mitSave;
	JMenuItem mitExit;
	
	public MyTextEditor() {
		initGUI();
	}
	
	private void initGUI() {
		try {
			//Main Frame settings
			setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
			pack();
			this.setTitle("Abhinav Text Editor");
			this.setSize(500, 600);
			BorderLayout borderLayout = new BorderLayout(5,5);
			this.setLayout(borderLayout);
			this.setLocationRelativeTo(null);
			//this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			//North Panel ========================
			pnlNorth = new JPanel();
			pnlNorth.setBorder(BorderFactory.createLineBorder(Color.black));
			
			//Font Label ========================
			lblFont = new JLabel("Font: ");
			pnlNorth.add(lblFont);
			
			//Font Size Spinner ========================
			spnFontSize = new JSpinner();
			spnFontSize.setPreferredSize(new Dimension(80,25));
			spnFontSize.setValue(15);
			spnFontSize.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					txaEditor.setFont(new Font(
											   txaEditor.getFont().getFamily(), 
											   Font.PLAIN, 
											   Integer.parseInt(spnFontSize.getValue().toString())
									  )); 
				}
			});
			pnlNorth.add(spnFontSize);
			
			// Font Family ========================
			String[] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();

			cmbFont = new JComboBox(fonts);
			cmbFont.setSelectedItem("Arial");
			cmbFont.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					txaEditor.setFont(new Font(
									  		(String)cmbFont.getSelectedItem(),
									  		Font.PLAIN,
									  		txaEditor.getFont().getSize()
									  ));
				}
			});
			
			pnlNorth.add(cmbFont);

			// Font Color Chooser ========================
			btnFontColor = new JButton("Color");
			btnFontColor.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					JColorChooser colorChooser = new JColorChooser();
					Color color = colorChooser.showDialog(null, "Choose a color", Color.black);
					txaEditor.setForeground(color);				
				}
			});
			pnlNorth.add(btnFontColor);
			
			this.add(pnlNorth, BorderLayout.NORTH);
			
			
			//Text Editor ======================
			txaEditor = new JTextArea();
			txaEditor.setLineWrap(true);
			txaEditor.setWrapStyleWord(true);
			txaEditor.setFont(new Font("Arial",Font.PLAIN,15));

			scpEditor = new JScrollPane(txaEditor);
			scpEditor.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			
			this.add(scpEditor, BorderLayout.CENTER);

			
			menuBar = new JMenuBar();
			mnuFile = new JMenu("File");
			mitOpen = new JMenuItem("Open");
			mitSave = new JMenuItem("Save");
			mitExit = new JMenuItem("Exit");

			//Open - MenuItem
			mitOpen.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					JFileChooser fileChooser = new JFileChooser();
					fileChooser.setCurrentDirectory(new File("."));
					FileNameExtensionFilter filter = new FileNameExtensionFilter("Text files", "txt");
					fileChooser.setFileFilter(filter);

					int response = fileChooser.showOpenDialog(null);

					if(response == JFileChooser.APPROVE_OPTION) {
						File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
						Scanner fileIn = null;

						try {
							fileIn = new Scanner(file);
							if(file.isFile()) {
								while(fileIn.hasNextLine()) {
									String line = fileIn.nextLine()+"\n";
									txaEditor.append(line);
								}
							}
						} catch (FileNotFoundException e1) {
							e1.printStackTrace();
						}
						finally {
							fileIn.close();
						}
					}
				}
				
			});
			
			//Save - MenuItem ==============
			mitSave.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					
					JFileChooser fileChooser = new JFileChooser();
					fileChooser.setCurrentDirectory(new File("."));

					int response = fileChooser.showSaveDialog(null);

					if(response == JFileChooser.APPROVE_OPTION) {
						File file;
						PrintWriter fileOut = null;

						file = new File(fileChooser.getSelectedFile().getAbsolutePath());
						try {
							fileOut = new PrintWriter(file);
							fileOut.println(txaEditor.getText());
						} 
						catch (FileNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						finally {
							fileOut.close();
						}   
					}
				}
			});
			
			//Exit - MenuItem
			mitExit.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent arg0) {
					System.exit(0);
				}
			});

			mnuFile.add(mitOpen);
			mnuFile.add(mitSave);
			mnuFile.add(mitExit);
			menuBar.add(mnuFile);

			//Adding Components
			this.setJMenuBar(menuBar);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


//public class MyTextEditorRunner {
	
	public static void main(String[] args) {
		  
		 MyTextEditor myTextEditor =  new MyTextEditor();
		 myTextEditor.setVisible(true);
	}
}

